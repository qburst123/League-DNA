# Betika Virtual Edge Analyzer

> ⚖️ **Statistical analysis + paper-betting ledger — not a prediction service
> that guarantees profit.** Virtual football outcomes are random draws unless a
> genuine exploitable bias is proven by large-sample backtesting.  The
> analyzer surfaces candidate edges from market prices vs a fitted
> Poisson model so you can keep your own records.

This is now a **native workspace** inside the **League-DNA v2.9.0** FastAPI
app — same React frontend, same `/api/*` conventions, same `Live / Snapshot`
sidebar indicator.  Open it from the sidebar: **"Betika virtual edge analyzer"**.

For legacy / reference purposes a thin CLI is kept at `betika_analyzer/scraper.py`
(see below).  The old Streamlit UI has been retired.

---

## 🛑 Guardrails

* Only public, read-only endpoints under
  `https://virtuals.betika.com/v1/` (the same routes the live collector
  uses — `competition`, `matches`, `matches/ongoing`, `matches/results`,
  `match`).  No authentication bypass, no CAPTCHA defeat, no private APIs.
* 1 request / 2 s, disk-cached, robots.txt-aware.
* Never writes to the live `data/league.sqlite`.  Writes go to
  `data/edge.sqlite` (four analyzer-owned tables: `edge_markets_cache`,
  `edge_h2h`, `edge_ledger`, `edge_settings`).
* Even if the site is unreachable, the bundled fixtures under
  `tests/fixtures/` are used so the workspace is always populated.

---

## ▶ Run

```bash
cd League-DNA
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python run.py            # serves on http://localhost:8000
```

Then in the browser, navigate to **Betika virtual edge analyzer** in the
sidebar.  The pre-built `web/assets/index-BIUedVU-.js` carries the new
component; rebuild via `cd frontend && npm run build` after editing
`frontend/src/BetikaEdge.jsx`.

---

## ▶ Tabs in the workspace

| # | Tab | Purpose |
|---|---|---|
| 1 | Data Collection | Bootstrap H2H + markets cache, seed synthetic H2H, view status |
| 2 | Teams | All 16 BSL teams with attack / defence / form / goal distribution |
| 3 | H2H Explorer | Directional H2H (home-away vs away-home), rule check, meetings table |
| 4 | Goal Distribution | Fitted bivariate Poisson / Dixon-Coles parameters + per-team profile |
| 5 | Predictions | Fair probabilities for any fixture, top-3 most-likely exact scores |
| 6 | Market Bias | Raw / overround / no-vig / margin + cross-market consistency flags |
| 7 | Value Bets | Positive-EV outcomes with fractional-Kelly stake |
| 8 | Paper Ledger | Two-market side-by-side ledger (Away Exact = 1 / Away Total OVER 1.5) |
| 9 | Matchday Tracker | MD1 → MD30 board with rule check, results, P/L |
| 10 | Settings | min_edge, Kelly fraction, H2H thresholds, stake, bankroll, min odds |

---

## ▶ Two-market strategy

Market A — *Away team EXACT GOALS = 1*
Market B — *Away team TOTAL goals OVER 1.5*

Entry rule (enforced by code in `backend/betika_edge/ledger.py`):

1. Both markets' decimal odds must be ≥ `min_odds` (default 2.00).
2. The H2H record for the fixture must show that BOTH teams scored > 0.5 goals
   in at least `h2h_both_gt_05` (default 60%) of the recorded meetings,
   with at least `h2h_min_meetings` (default 3) meetings.

Settlement (auto, after the FT result is recorded):

* A wins only if the away team scored exactly 1.
* B wins if the away team scored 2 or more.

Per-column and combined P/L, bankroll, ROI, max-drawdown and longest
win/loss streak are reported.

---

## ▶ CLI (legacy)

The standalone CLI is kept for one-shot fetches:

```bash
python betika_analyzer/scraper.py bootstrap            # load bundled fixtures + H2H
python betika_analyzer/scraper.py probe                # one-shot /competition probe
python betika_analyzer/scraper.py warm SEASON MD       # fetch one matchday's results
```

All of these are layered on top of the same FastAPI service, so the
React workspace is always the authoritative surface.

---

## ⚠ Responsibility

Independent research.  No fabricated teams, no fabricated scores.  No
wagering actions.  No profit guarantee.  Treat the ledger as a paper-
tracking tool for statistical edge detection, not a forecast.
