"""Betika Virtual Edge Analyzer — package marker."""
