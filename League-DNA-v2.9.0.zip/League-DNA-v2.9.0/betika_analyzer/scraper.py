"""Standalone CLI scraper for the Betika Virtual Edge Analyzer.

This is a thin convenience script — the real integration is the
`backend/betika_edge` package, which is also exposed through the
League-DNA FastAPI server (`/api/betika-edge/*`).  Run the server,
hit those endpoints from the React workspace; reach for this CLI
only when you want to poke the public feeds directly without booting
the FastAPI process.

Run::

    python scraper.py bootstrap            # load bundled fixtures + H2H
    python scraper.py probe                # one-shot /competition probe
    python scraper.py warm SEASON MD       # fetch one matchday's results

Same guardrails as the live collector:

* GET-only against https://virtuals.betika.com/v1/ (competition_id=26).
* 1 request / 2 seconds.
* Every response is cached to ./cache/<sha256>.json.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from backend.betika_edge import edge as betika  # noqa: E402
from backend.betika_edge.scraper_public import BetikaVirtualScraper  # noqa: E402

log = logging.getLogger("betika.cli")


def main():
    ap = argparse.ArgumentParser(description="Betika Virtual Edge Analyzer CLI")
    sub = ap.add_subparsers(dest="cmd", required=False)

    sub.add_parser("bootstrap", help="Load bundled fixtures + refresh H2H into data/edge.sqlite")
    sub.add_parser("probe", help="Probe the live competition endpoint")
    p_warm = sub.add_parser("warm", help="Fetch one matchday's results")
    p_warm.add_argument("season", type=int)
    p_warm.add_argument("matchday", type=int)

    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s | %(message)s")

    if args.cmd == "bootstrap":
        info = betika.refresh()
        print(json.dumps(info, indent=2, default=str))
        return
    if args.cmd == "probe":
        s = BetikaVirtualScraper()
        print(json.dumps(s.probe_competition(), indent=2, default=str))
        return
    if args.cmd == "warm":
        s = BetikaVirtualScraper()
        rows = s.fetch_results(args.season, args.matchday)
        print(f"fetched {len(rows)} rows for S{args.season} MD{args.matchday}")
        for r in rows:
            print(f"  {r.get('home_team')} vs {r.get('away_team')}  "
                  f"HT={r.get('saved_ht_score') or r.get('ht_score')}  "
                  f"FT={r.get('saved_ft_score') or r.get('ft_score')}")
        return

    ap.print_help()


if __name__ == "__main__":
    main()
